# INE
## primer commit 05/07/2022
### sobre como hacer clases https://mirrors.ucr.ac.cr/CTAN/macros/latex/base/clsguide.pdf

building 'pyodbc' extension
      error: Microsoft Visual C++ 14.0 or greater is required. Get it with "Microsoft C++ Build Tools": https://visualstudio.microsoft.com/visual-cpp-build-tools/
https://wiki.python.org/moin/WindowsCompilers#Microsoft_Visual_C.2B-.2B-_14.2_standalone:_Build_Tools_for_Visual_Studio_2019_.28x86.2C_x64.2C_ARM.2C_ARM64.29